<?php

$server = "localhost";
$username = "root";
$pass = "123456";
$db = "db_instagram";

$koneksi = mysqli_connect ($server,$username,$pass, $db);
?>