<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("location:login.php");
}
include "koneksi.php";

$no = $_GET['no'];
$sql = "SELECT * FROM post WHERE no = '$no'";
$query = mysqli_query($koneksi, $sql);

while($post = mysqli_fetch_assoc($query)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="icon" href="img/reh1.png"> 
    <title>RAYYSTORE</title>
</head>
<body>
<nav class="navbar sticky-top navbar-expand-lg" style="background-color: white; " >
<div class="container-fluid">
<img src="img/1234.png" height="65" width="250" >
<strong><a class="text-danger navbar-brand sticky-top"  href="#">POSTINGAN</a></strong><div>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <!-- <div a class="nav-link active" aria-current="page" href="index.php">Postingan</a></div> -->
      </li>
      </li>
    </ul>
    <div align="right">
    <a href="index.php" class="btn btn-success"><i class="fa-solid fa-square-caret-left" style="color: #ffffff;"></i></a>
  <a href="logout.php" class="btn btn-danger">LOGOUT<i class="fa-solid fa-arrow-right-from-bracket fa-xl " style="color: #ffffff;"></i></a>
</div>
</div>
</div>
</nav><br><br>
    <div class="container">
        <h1 align>Edit Postingan</h1>
        <form action="prosesedit.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="no" value="<?= $post['no'] ?>">
            <input type="hidden" name="gambar" value="<?= $post['gambar'] ?>">

            <label class="form-label">Gambar</label><br>
            <input type="file" name="gambar" value="<?= $post['gambar'] ?>" class="form-control" required><br>

            <label class="form-label">Caption</label><br>
            <input type="textarea" name="caption" value="<?= $post['caption'] ?>" class="form-control" autocomplete="off" required><br>

            <label class="form-label">Lokasi</label><br>
            <input type="text" name="lokasi" value="<?= $post['lokasi'] ?>" class="form-control" autocomplete="off" required><br>

            <img src="images/<?= $post['gambar'] ?>" width="100" alt="" class="mb-3"><br>

            <button type="submit" class="btn btn-primary" name="update">Simpan</button>
        </form>
    </div>
</body>
</html>
<?php } ?>    
</div>
