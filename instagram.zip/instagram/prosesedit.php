<?php

include "koneksi.php";
require "functions.php";

if (isset($_POST['update'])) {
    $no = $_POST['no'];
    $gambar = $_POST['gambar'];
    $caption = $_POST['caption'];
    $lokasi = $_POST['lokasi'];
    $gambar_lama = $_FILES['gambar']['name'];

    if ($_FILES['gambar']['error'] === 4) {
        $gambar = $gambar_lama;
    } else {
        $sql = "SELECT * FROM post WHERE no = '$no'";
        $query = mysqli_query($koneksi, $sql);

        while($post = mysqli_fetch_assoc($query)) {
            $gambar = $instagram['gambar'];
            unlink('images/' . $gambar);
        }
        $gambar = upload();
    }
    $sql2 = "UPDATE post SET gambar = '$gambar', caption = '$caption', lokasi = '$lokasi' WHERE no = '$no'";
    $query2 = mysqli_query($koneksi, $sql2);

    if ($query2) {
        header("location:index.php?edit=sukses");
    } else {
        header("location:index.php?edit=gagal");
    }
}
?>