<?php

include "koneksi.php";
$sql = "SELECT * FROM post";
$query = mysqli_query($koneksi, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
    <link rel="icon" href="img/reh1.png" href="style2.css"> 
    <title>RAYYSTORE</title>

</head>
    <style>
.zoom {
  transition: transform .2s; /* Animation */
  margin:0 auto;
}

.zoom:hover {
  transform: scale(1.2); /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
}
      body {
      background-image: url('img/backk.jpg');
      background-position: absolute;
      background-size: 1350px;
      background-repeat: no-repeat repeat-x;
      
      }
      
</style>
<body>
 
<nav class="navbar sticky-top navbar-expand-lg shadow-lg" style="background-color: white; " >
<div class="container-fluid">
<img src="img/1234.png" height="65" width="250" >
    <strong><a class="text-danger navbar-brand sticky-top"  href="#">POSTINGAN</a></strong><div>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <!-- <div a class="nav-link active" aria-current="page" href="index.php">Postingan</a></div> -->
      </li>
      </li>
    </ul>
    <div align="right">
  <i class="fa-solid fa-folder-plus fa-lg" style="color: #ffffff;"></i>
    <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#exampleModal" ><i class="fa-solid fa-folder-plus fa-lg" style="color: #ffffff;"></i></button>
  <a href="logout.php" class="btn btn-danger">LOGOUT<i class="fa-solid fa-arrow-right-from-bracket fa-xl " style="color: #ffffff;"></i></a>
</div>
</div>
</div>
</nav><br><br>
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 align="center" class="modal-title fs-5" id="staticBackdropLabel">Form Tambah</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_tambah.php" method="POST" enctype="multipart/form-data">
        <label for="">Foto</label><br>
        <input type="file" name="gambar" class="form-control"><br>
        <label for="">Caption</label><br>
        <input type="text" name="caption" class="form-control" autocomplete="off"><br>
        <label for="">Harga</label><br>
        <input type="text" name="lokasi" class="form-control" autocomplete="off"><br>
        <input type="submit" value="Simpan" name="simpan" class="btn" style="background: #37BABF;">
    </form>
    </div>
    </div>
  </div>
</div>

<div align="center" class="container mt-3">
        <?php while($post = mysqli_fetch_assoc($query)) { ?>
            <div align="left" class="card mb-3" style="width: 20rem;">
                <div class="zoom">
                <img class="card-img-top" src="images/<?= $post['gambar'] ?>" height="300" width="280" alt="">
                </div>
                <div class="card-body">
                    <h5 class="card-title"><?= $post['caption'] ?></h5>
                    <p class="card-text">
                        <?= $post['lokasi'] ?>
                    </p>
                    <!-- <a href="edit.php?no="><button class="btn btn-sm" style="background: linear-gradient(-135deg, #c850c0, #4158d0); color: white;"><i class="fa-solid fa-pencil"></i></button></a> -->
                    <button data-bs-toggle="modal" data-bs-target="#modalEdit<?= $post['no'] ?>" class="btn btn-warning btn-sm"><i class="fa-solid fa-pencil"></i></button>
                    <a href="hapus.php?no=<?= $post['no'] ?>"><button class="btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i></button></a>
                    <a href="#"><button class="btn btn-success btn-sm"><i class="fa-solid fa-cart-plus"></i></button></a>
                </div>
            </div>
    
    <div class="modal fade" id="modalEdit<?= $post['no'] ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel">Form Edit</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="proses_edit.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="no" value="<?= $post['no'] ?>">
            <div align="left">
            <input type="hidden" name="gambar" value="<?= $post['gambar'] ?>">
            </div>
            <div align="left">
            <label class="form-label">Gambar</label><br>
            <input type="file" name="gambar" value="<?= $post['gambar'] ?>" class="form-control" ><br>
            </div>
            <div align="left">
            <img src="images/<?= $post['gambar'] ?>" width="100" alt="" class="mb-3"><br>
            </div>
            <div align="left">
            <label class="form-label">Caption</label><br>
            <input type="textarea" name="caption" value="<?= $post['caption'] ?>" class="form-control" autocomplete="off" required><br>
            </div>
            <div align="left">
            <label class="form-label">Harga</label><br>
            <input type="text" name="lokasi" value="<?= $post['lokasi'] ?>" class="form-control" autocomplete="off" required><br>
            </div>
            <div align="left">
            <button type="submit" class="btn" style="background: #37BABF;" name="update">Simpan</button>
            </div>
        </form>
      </div>
      <!-- <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div> -->
    </div>
  </div>
 </div>
<?php } ?>
</div>
</html>